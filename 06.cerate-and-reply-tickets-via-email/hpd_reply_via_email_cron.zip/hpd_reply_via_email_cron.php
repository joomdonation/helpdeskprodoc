<?php
// Replace test with the value you entered into Secret Code parameter inside System - Helpdeskpro Reply Via Email plugin

$_REQUEST['secret_code'] = 'test';

require_once __DIR__ . '/index.php';